// import express from 'express';
// import * as authService from '../../service/main/login.js';

// const router = express.Router();

// router.post('/login', authService.login);

// export default router;